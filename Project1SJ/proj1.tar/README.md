mytree: To compile mytree execute the following in terminal
>make mytree

mytime: To compile mytime execute the following in terminal
>make mytime

mymtimes: To compile mymtimes execute the following in terminal
>make mymtimes

To cleanup the compiled executables, execute the following in terminal
> make clean
