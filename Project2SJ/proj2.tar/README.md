To compile all files, execute the following in terminal
>make

mytoolkit: To compile mytoolkit program, execute the following in terminal
>make mytoolkit

mytimeout: To compile mytimeout program, execute the following in terminal
>make mytmytimeoutime

To cleanup the compiled executables, execute the following in terminal
> make clean