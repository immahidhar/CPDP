# Project 1
Class: COP 5570

Professor: Zhenhai Duan

Name: Mahidhar Reddy Narala (MN22L)


There are three programs in this project.


**To compile all three programs at a time, execute the following in terminal**
```
make
```

**To cleanup the compiled executables, execute the following in terminal**
```
make clean
```

## mytree:
To compile mytree execute the following in terminal
```
make mytree
```
To run mytree execute the following in terminal
```
./mytree.x args...
```

## mytime:
To compile mytime execute the following in terminal
```
make mytime
```
To run mytime execute the following in terminal
```
./mytime.x args...
```

## mymtimes:
To compile mymtimes execute the following in terminal
```
make mymtimes
```
To run mymtimes execute the following in terminal
```
./mymtimes.x args...
```
