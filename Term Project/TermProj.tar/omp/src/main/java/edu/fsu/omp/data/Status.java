package edu.fsu.omp.data;

public enum Status {
    ORDERED, SHIPPED, DELIVERED, RETURNED
}
