package edu.fsu.omp.data;

public enum Category {
shoes, sandals, shirts, pants, shorts, books, mobiles, computers
}
